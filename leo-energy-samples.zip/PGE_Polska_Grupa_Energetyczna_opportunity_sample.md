# PGE Polska Grupa Energetyczna — Free Opportunity Sample Report

> **LEO Europe Energy Opportunity Intelligence — Sample**
> Generated: 2026-08-16 · Source: TED / UK Contracts Finder (public data) · Not a solicitation

---

## 1. Opportunity Summary

| Field | Detail |
|---|---|
| **Title** | Supply of 2 Zero-Emission Buses + Charging Infrastructure (MZK Tomaszów Mazowiecki) |
| **Notice No.** | 447933-2025 |
| **Source** | TED |
| **Category** | EV Charging / e-bus |
| **Country** | Poland |
| **Est. Value** | €6,500,000 |
| **Deadline** | Published 2025 |
| **Buyer** | Miejski Zakład Komunikacyjny w Tomaszowie Mazowieckim |
| **Buyer Contact** | mzk@tomaszow-maz.pl (MZK Procurement) |
| **Source URL** | https://ted.europa.eu/en/notice/-/detail/447933-2025 |

## 2. Why This Matters for PGE Polska Grupa Energetyczna

Polish zero-emission bus + charging procurement wave; PGE operates charging & distribution networks.

## 3. Opportunity Description

Supply of 2 zero-emission buses (10m low-floor electric e-buses incl. battery charging infrastructure, main charging equipment). eZamówienia platform.

## 4. What You Could Do (Next Steps)

1. **Assess fit** — confirm this category (or the adjacent pipeline it signals) matches PGE Polska Grupa Energetyczna capabilities.
2. **Track the buyer** — monitor Miejski Zakład Komunikacyjny w Tomaszowie Mazowieckim procurement pipeline via TED/Contracts Finder alerts.
3. **Prepare capability materials** — 1-page evidence sheet for similar contracts already delivered.
4. **Partner or bid** — decide whether to bid directly or partner with a local EPC/installer.
5. **Subscribe to LEO Europe Energy Opportunity Intelligence** — full Pro/Business tier gives daily scans, decision-maker lists, and pre-drafted proposal briefs for your target countries.

## 5. Data Provenance

- **Retrieved At:** 2026-08-16
- **Source:** TED public notice 447933-2025
- **Verification:** Real tender record fetched from public source; contact details as published.
- **Disclaimer:** Market data from public tenders. LEO Intelligence does not guarantee award outcomes. Always verify deadlines & terms on the source platform.

---
*This sample is free of charge. For the full Pro tier (€49/mo) or Business tier (€199/mo), contact LEO Intelligence.*
