# Ørsted A/S — Free Opportunity Sample Report

> **LEO Europe Energy Opportunity Intelligence — Sample**
> Generated: 2026-08-16 · Source: TED / UK Contracts Finder (public data) · Not a solicitation

---

## 1. Opportunity Summary

| Field | Detail |
|---|---|
| **Title** | AVV Square 2.0 Project — Battery Energy Storage System (BESS), 20MW/2h |
| **Notice No.** | 693469-2025 |
| **Source** | TED |
| **Category** | BESS |
| **Country** | Denmark |
| **Est. Value** | €11,350,000 |
| **Deadline** | Publication 2025-08-05; award phase |
| **Buyer** | Ørsted Bioenergy & Thermal Power A/S |
| **Buyer Contact** | miklo@orsted.com (Senior Sourcing Manager, BIO Strategic Sourcing) |
| **Source URL** | https://ted.europa.eu/en/notice/-/detail/693469-2025 |

## 2. Why This Matters for Ørsted A/S

Ørsted's own Avedøre BESS tender — adjacent opportunity for their BESS supply chain and power plant team.

## 3. Opportunity Description

BESS installed at Avedøreværket power station (Avedøre, Hvidovre). Min 20 MW usable / ~2h. Ancillary services FCR-N/FCR-D/FFR/aFRR/mFRR for Energinet DK2. Scope: battery bank, inverter, BESS transformer, MV interface, EMS, metering, +2y maintenance (opt +4y).

## 4. What You Could Do (Next Steps)

1. **Assess fit** — confirm this category (or the adjacent pipeline it signals) matches Ørsted A/S capabilities.
2. **Track the buyer** — monitor Ørsted Bioenergy & Thermal Power A/S procurement pipeline via TED/Contracts Finder alerts.
3. **Prepare capability materials** — 1-page evidence sheet for similar contracts already delivered.
4. **Partner or bid** — decide whether to bid directly or partner with a local EPC/installer.
5. **Subscribe to LEO Europe Energy Opportunity Intelligence** — full Pro/Business tier gives daily scans, decision-maker lists, and pre-drafted proposal briefs for your target countries.

## 5. Data Provenance

- **Retrieved At:** 2026-08-16
- **Source:** TED public notice 693469-2025
- **Verification:** Real tender record fetched from public source; contact details as published.
- **Disclaimer:** Market data from public tenders. LEO Intelligence does not guarantee award outcomes. Always verify deadlines & terms on the source platform.

---
*This sample is free of charge. For the full Pro tier (€49/mo) or Business tier (€199/mo), contact LEO Intelligence.*
