# Elia Group — Free Opportunity Sample Report

> **LEO Europe Energy Opportunity Intelligence — Sample**
> Generated: 2026-08-16 · Source: TED / UK Contracts Finder (public data) · Not a solicitation

---

## 1. Opportunity Summary

| Field | Detail |
|---|---|
| **Title** | Battery Energy Storage System (BESS) at Merksem WWTP |
| **Notice No.** | 863953-2025 |
| **Source** | TED |
| **Category** | BESS |
| **Country** | Belgium |
| **Est. Value** | €828,416.40 |
| **Deadline** | Published 2025 |
| **Buyer** | Aquafin NV |
| **Buyer Contact** | guido.cuyckens@aquafin.be (Guido Cuyckens) |
| **Source URL** | https://ted.europa.eu/en/notice/-/detail/863953-2025 |

## 2. Why This Matters for Elia Group

Belgian TSO — BESS connections at industrial sites (Merksem) align with Elia's grid services market.

## 3. Opportunity Description

BESS at Merksem wastewater treatment plant. Water utility investing in behind-the-meter storage to cut grid charges and support peak shaving.

## 4. What You Could Do (Next Steps)

1. **Assess fit** — confirm this category (or the adjacent pipeline it signals) matches Elia Group capabilities.
2. **Track the buyer** — monitor Aquafin NV procurement pipeline via TED/Contracts Finder alerts.
3. **Prepare capability materials** — 1-page evidence sheet for similar contracts already delivered.
4. **Partner or bid** — decide whether to bid directly or partner with a local EPC/installer.
5. **Subscribe to LEO Europe Energy Opportunity Intelligence** — full Pro/Business tier gives daily scans, decision-maker lists, and pre-drafted proposal briefs for your target countries.

## 5. Data Provenance

- **Retrieved At:** 2026-08-16
- **Source:** TED public notice 863953-2025
- **Verification:** Real tender record fetched from public source; contact details as published.
- **Disclaimer:** Market data from public tenders. LEO Intelligence does not guarantee award outcomes. Always verify deadlines & terms on the source platform.

---
*This sample is free of charge. For the full Pro tier (€49/mo) or Business tier (€199/mo), contact LEO Intelligence.*
